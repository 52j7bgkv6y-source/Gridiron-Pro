-- ════════════════════════════════════════════════════════════════════════
--  GRIDIRON PRO — team backend (Step 1)
--  Paste this whole file into Supabase → SQL Editor → Run.
--  Safe to re-run: every statement is idempotent.
-- ════════════════════════════════════════════════════════════════════════

-- 1) TEAMS — one row per school/team (a tenant)
create table if not exists public.teams (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  created_by  uuid references auth.users(id),
  created_at  timestamptz default now()
);

-- 2) MEMBERSHIPS — who is on a team and what they can do
--    role: 'admin' | 'coadmin' | 'coach' | 'player'
create table if not exists public.memberships (
  id            uuid primary key default gen_random_uuid(),
  team_id       uuid not null references public.teams(id) on delete cascade,
  user_id       uuid not null references auth.users(id) on delete cascade,
  role          text not null default 'player' check (role in ('admin','coadmin','coach','player')),
  display_name  text,
  created_at    timestamptz default now(),
  unique (team_id, user_id)
);

-- 3) INVITE CODES — the random code someone enters to get in.
--    team_id NULL = a "founder" code: redeeming it creates a NEW team and
--    makes the redeemer that team's admin. Otherwise it joins an existing team.
create table if not exists public.invite_codes (
  code           text primary key,
  team_id        uuid references public.teams(id) on delete cascade,
  role           text not null default 'player' check (role in ('admin','coadmin','coach','player')),
  new_team_name  text,
  created_by     uuid references auth.users(id),
  used_by        uuid references auth.users(id),
  used_at        timestamptz,
  max_uses       int default 1,
  uses           int default 0,
  created_at     timestamptz default now()
);

-- 4) TEAM DATA — the playbook itself. One row per storage key per team, so a
--    team's library is fully isolated and code updates never touch it.
create table if not exists public.team_data (
  team_id     uuid not null references public.teams(id) on delete cascade,
  key         text not null,
  value       jsonb,
  updated_by  uuid references auth.users(id),
  updated_at  timestamptz default now(),
  primary key (team_id, key)
);

-- ── Security helpers (SECURITY DEFINER → they bypass RLS, which avoids the
--    infinite-recursion trap you hit when a membership policy queries
--    memberships) ──────────────────────────────────────────────────────────
create or replace function public.is_member(p_team uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.memberships
                 where team_id = p_team and user_id = auth.uid())
$$;

create or replace function public.my_role(p_team uuid)
returns text language sql stable security definer set search_path = public as $$
  select role from public.memberships
  where team_id = p_team and user_id = auth.uid()
$$;

-- ── Turn on row-level security ──────────────────────────────────────────────
alter table public.teams        enable row level security;
alter table public.memberships  enable row level security;
alter table public.invite_codes enable row level security;
alter table public.team_data    enable row level security;

-- TEAMS: you can see a team only if you belong to it
drop policy if exists teams_read on public.teams;
create policy teams_read on public.teams for select
  using (public.is_member(id));

-- MEMBERSHIPS: see everyone on your teams; admins/co-admins can manage members
drop policy if exists memberships_read on public.memberships;
create policy memberships_read on public.memberships for select
  using (public.is_member(team_id));

drop policy if exists memberships_manage on public.memberships;
create policy memberships_manage on public.memberships for all
  using (public.my_role(team_id) in ('admin','coadmin'))
  with check (public.my_role(team_id) in ('admin','coadmin'));

-- INVITE CODES: admins/co-admins manage codes for their own team
drop policy if exists codes_manage on public.invite_codes;
create policy codes_manage on public.invite_codes for all
  using (team_id is not null and public.my_role(team_id) in ('admin','coadmin'))
  with check (team_id is not null and public.my_role(team_id) in ('admin','coadmin'));

-- TEAM DATA: any member can READ; only coach/co-admin/admin can WRITE
drop policy if exists data_read on public.team_data;
create policy data_read on public.team_data for select
  using (public.my_role(team_id) is not null);

drop policy if exists data_insert on public.team_data;
create policy data_insert on public.team_data for insert
  with check (public.my_role(team_id) in ('admin','coadmin','coach'));

drop policy if exists data_update on public.team_data;
create policy data_update on public.team_data for update
  using (public.my_role(team_id) in ('admin','coadmin','coach'))
  with check (public.my_role(team_id) in ('admin','coadmin','coach'));

drop policy if exists data_delete on public.team_data;
create policy data_delete on public.team_data for delete
  using (public.my_role(team_id) in ('admin','coadmin','coach'));

-- ── Protect the admin: a co-admin (or anyone else) can do everything EXCEPT
--    remove or demote the team's admin. Only the admin can change their own
--    admin role. ──────────────────────────────────────────────────────────
create or replace function public.protect_admin()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (TG_OP = 'DELETE') then
    if OLD.role = 'admin' and OLD.user_id <> auth.uid() then
      raise exception 'Only the admin can remove the admin';
    end if;
    return OLD;
  else -- UPDATE
    if OLD.role = 'admin' and NEW.role <> 'admin' and OLD.user_id <> auth.uid() then
      raise exception 'Only the admin can change the admin role';
    end if;
    return NEW;
  end if;
end $$;

drop trigger if exists trg_protect_admin on public.memberships;
create trigger trg_protect_admin before update or delete on public.memberships
  for each row execute function public.protect_admin();

-- ── Redeem a code: join a team, or found one (atomic, runs as definer so a
--    brand-new user with no membership yet can be added safely) ─────────────
create or replace function public.redeem_code(p_code text, p_display text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v public.invite_codes; v_team uuid;
begin
  select * into v from public.invite_codes where code = p_code for update;
  if v.code is null then raise exception 'That code is not valid'; end if;
  if v.uses >= coalesce(v.max_uses, 1) then raise exception 'That code has already been used'; end if;

  if v.team_id is null then
    insert into public.teams(name, created_by)
      values (coalesce(v.new_team_name, 'My Team'), auth.uid())
      returning id into v_team;
    insert into public.memberships(team_id, user_id, role, display_name)
      values (v_team, auth.uid(), 'admin', p_display);
  else
    v_team := v.team_id;
    insert into public.memberships(team_id, user_id, role, display_name)
      values (v_team, auth.uid(), v.role, p_display)
      on conflict (team_id, user_id) do nothing;
  end if;

  update public.invite_codes
    set uses = uses + 1, used_by = auth.uid(), used_at = now()
    where code = p_code;
  return v_team;
end $$;

-- ── Generate an invite code for your team (admin/co-admin only) ─────────────
create or replace function public.generate_code(p_team uuid, p_role text, p_max_uses int default 1)
returns text language plpgsql security definer set search_path = public as $$
declare v_code text;
begin
  if public.my_role(p_team) not in ('admin','coadmin') then
    raise exception 'Only an admin or co-admin can create invite codes';
  end if;
  if p_role not in ('coadmin','coach','player') then
    raise exception 'Pick a role: co-admin, coach, or player';
  end if;
  v_code := upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8));
  insert into public.invite_codes(code, team_id, role, created_by, max_uses)
    values (v_code, p_team, p_role, auth.uid(), greatest(coalesce(p_max_uses, 1), 1));
  return v_code;
end $$;

-- ════════════════════════════════════════════════════════════════════════
--  FIRST TEAM: this founder code lets the first person sign up and become an
--  admin of a brand-new team. Change 'GRIDIRON1' / 'My School' to anything.
--  Delete or ignore it after your first admin signs up.
-- ════════════════════════════════════════════════════════════════════════
insert into public.invite_codes(code, team_id, role, new_team_name, max_uses)
values ('GRIDIRON1', null, 'admin', 'My School', 1)
on conflict (code) do nothing;
