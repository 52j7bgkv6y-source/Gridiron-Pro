/* ─────────────────────────────────────────────────────────────────────────────
   GRIDIRON service worker
   Strategy:
   • Navigations (the app page itself): NETWORK-FIRST with no-store, falling
     back to the cached copy when offline. This means every online open gets
     the freshest deploy automatically — no more hard-refresh after redeploys —
     while a dead practice-field connection still opens the last good version.
   • CDN libraries (React, ReactDOM, Supabase client, Babel) and Google Fonts:
     CACHE-FIRST — versioned/immutable enough, and caching them makes opens
     near-instant on slow school WiFi.
   • Supabase API traffic: NEVER intercepted (auth + live team data must always
     hit the network directly).
   Bump VERSION if you ever need to force old caches out.
   ──────────────────────────────────────────────────────────────────────────── */
const VERSION = "gridiron-v1";
const APP_CACHE = VERSION + "-app";
const LIB_CACHE = VERSION + "-lib";

const LIB_URLS = [
  "https://unpkg.com/react@18/umd/react.production.min.js",
  "https://unpkg.com/react-dom@18/umd/react-dom.production.min.js",
  "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2",
  "https://unpkg.com/@babel/standalone/babel.min.js",
  "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js",
];
const LIB_HOSTS = ["unpkg.com", "cdn.jsdelivr.net", "cdnjs.cloudflare.com", "fonts.googleapis.com", "fonts.gstatic.com"];

self.addEventListener("install", (e) => {
  e.waitUntil((async () => {
    const app = await caches.open(APP_CACHE);
    try { await app.addAll(["./", "./manifest.webmanifest", "./icon-192.png", "./icon-512.png"]); } catch (err) {}
    const lib = await caches.open(LIB_CACHE);
    await Promise.all(LIB_URLS.map(async (u) => {
      try { await lib.add(new Request(u, { mode: "no-cors" })); } catch (err) {}
    }));
    self.skipWaiting();
  })());
});

self.addEventListener("activate", (e) => {
  e.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.map((n) => (n.startsWith(VERSION) ? null : caches.delete(n))));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);

  // Live data: hands off. Let auth and team queries hit the network directly.
  if (url.hostname.endsWith(".supabase.co")) return;

  // The app page: fresh when online, cached when not.
  if (req.mode === "navigate") {
    e.respondWith((async () => {
      try {
        const fresh = await fetch(req, { cache: "no-store" });
        const app = await caches.open(APP_CACHE);
        app.put("./", fresh.clone());
        return fresh;
      } catch (err) {
        const app = await caches.open(APP_CACHE);
        return (await app.match("./")) || (await app.match(req)) || Response.error();
      }
    })());
    return;
  }

  // Libraries + fonts: cache-first, fill on miss.
  if (LIB_HOSTS.includes(url.hostname)) {
    e.respondWith((async () => {
      const lib = await caches.open(LIB_CACHE);
      const hit = await lib.match(req, { ignoreVary: true });
      if (hit) return hit;
      try {
        const res = await fetch(req);
        if (res && (res.ok || res.type === "opaque")) lib.put(req, res.clone());
        return res;
      } catch (err) {
        return Response.error();
      }
    })());
    return;
  }

  // Same-origin assets (icons, manifest): cache-first with network fill.
  if (url.origin === self.location.origin) {
    e.respondWith((async () => {
      const app = await caches.open(APP_CACHE);
      const hit = await app.match(req);
      if (hit) return hit;
      try {
        const res = await fetch(req);
        if (res && res.ok) app.put(req, res.clone());
        return res;
      } catch (err) {
        return Response.error();
      }
    })());
  }
});
